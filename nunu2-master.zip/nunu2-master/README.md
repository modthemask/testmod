# SELFBOT LINE PYTHON3

MAAF SOBAT FILE PYTHON DAN LAIN LAINYA TIDAK DI CANTUMKAN.
KARNA FILE SYSTEM BERBAYAR SILAHKAN GANTI IMPORT NYA AJA PADA
SCRIPT BOT KALIAN DENGAN COPY PASTEKAN DI BAWAH INI.

- CONFIGURATION IMPORT FILE
```
from linepy import *
from akad.ttypes import *
from multiprocessing import Pool, Process
from akad.ttypes import ContentType as Type
from datetime import datetime
import time,random,sys,json,codecs,threading,glob,re,os,subprocess
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
import time, random, sys, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, pytz, urllib, urllib.parse,youtube_dl,pafy,timeit,atexit,traceback
from gtts import gTTS
from googletrans import Translator

```

- LINE UPDATE
juni 2018
## [SUBCRABE NOW](https://www.youtube.com/channel/UCycBrqSWEHdk-slnhUmGWiQ)
KLIK
## [CREATOR](http://line.me/ti/p/~max_pv)

#SELFBOT PYHON3
------
- `apt update`
- `apt upgrade`
- `apt install git`
- `apt install python3-pip`
- `pip3 install rsa`
- `pip3 install thrift==0.11.0`
- `pip3 install requests`
- `pip3 install bs4`
- `pip3 install gtts`
- `pip3 install pytz`
- `pip3 install humanfriendly`
- `pip3 install googletrans`
- `pip3 install youtube_dl`
- `pip3 install pafy`
- `git clone https://github.com/0954517662/MAXZA`

- 'Cara Run Bot'
- Ketik -> `cd Gye`
- Ketik -> `python3 gi4.py`
- `Jangan Lupa Kalian isi Dulu Token nya`
- `Edit via nano Atau storage`

- 'untuk Run Via storage'
- `cd storage`
- `cd downloads`
- `cd linebot`
- `python3 max4.py`

- thank id Line me ( max_pv )
